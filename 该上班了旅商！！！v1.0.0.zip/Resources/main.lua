-- 该上班了旅商！！！ —— 让旅行商人（旅商）每天都到访
-- 作者：KMLG666
-- 介绍：可怜的打工人！
--
-- 原理：每个新的一天（白天开始）时，如果场上还没有旅商，
--       就先调用 Chest.SetupTravelShop() 重构货架，再用 NPC.NewNPC 刷出旅商（NPC ID 368）。

mod.meta = { pkg_id = "kmlg666.lua.lvshangdaily", version = "1.0.0" }

local patch = mod.patch

-- 旅商 NPC ID
local TRAVELING_MERCHANT = 368

-- 缓存：类型 / 字段 / 方法
local T_MAIN, T_NPC, T_CHEST
local F_dayTime, F_netMode, F_spawnTileX, F_spawnTileY, F_npc
local F_npc_active, F_npc_type
local M_new_npc, M_new_npc_argc, M_setup_shop, M_tick

local ready = false
local checked_today = false   -- 当天是否已经检查/处理过

-- 场上是否已经存在旅商
local function merchant_exists()
    local arr = patch.get_field_value(F_npc, nil, "object")
    if not arr then return false end
    local n = patch.array_length(arr)
    for i = 0, n - 1 do                       -- 数组为 0-based
        local ok, npc = pcall(patch.array_at, arr, i)
        if ok and npc then
            if patch.get_field_value(F_npc_active, npc, "bool") then
                if patch.get_field_value(F_npc_type, npc, "int32") == TRAVELING_MERCHANT then
                    return true
                end
            end
        end
    end
    return false
end

-- 刷出旅商（先重构货架，再刷人）
local function spawn_merchant()
    if M_setup_shop then pcall(patch.invoke, M_setup_shop) end

    local x = patch.get_field_value(F_spawnTileX, nil, "int32")
    local y = patch.get_field_value(F_spawnTileY, nil, "int32")
    if not x or not y then return end

    -- NPC.NewNPC(X, Y, Type, Start, ai0, ai1, ai2, ai3, Target) —— 按实际参数个数补齐
    local args = { x * 16, y * 16, TRAVELING_MERCHANT, 1 }
    if M_new_npc_argc and M_new_npc_argc > 4 then
        for i = 5, M_new_npc_argc do args[i] = 0 end
        args[M_new_npc_argc] = 255            -- 最后一个参数是 Target
    end
    pcall(patch.invoke, M_new_npc, table.unpack(args))
end

-- 每帧回调（挂在 Main 的每帧方法上）
local function tick(instance, args, result)
    if not ready then return end

    -- 联机客户端不刷，交给主机/单人世界
    local net = patch.get_field_value(F_netMode, nil, "int32")
    if net == 1 then return end

    -- 到夜晚：重置标记，为第二天做准备（旅商默认会在此后离开）
    if not patch.get_field_value(F_dayTime, nil, "bool") then
        checked_today = false
        return
    end

    -- 白天，每天只检查一次
    if checked_today then return end
    checked_today = true

    if merchant_exists() then return end
    spawn_merchant()
    mod.info("该上班了旅商！！！ —— 可怜的打工人又来上班啦 ~")
end

-- 在 Main 上按名称 + 参数个数依次尝试解析静态方法
local function resolve_main(name, argcs)
    for _, n in ipairs(argcs) do
        local m = patch.get_method(T_MAIN, name, n)
        if m then return m end
    end
    return patch.get_method(T_MAIN, name)
end

function setup()
    T_MAIN  = patch.get_type("Terraria", "Main")
    T_NPC   = patch.get_type("Terraria", "NPC")
    T_CHEST = patch.get_type("Terraria", "Chest")
    if not (T_MAIN and T_NPC and T_CHEST) then
        mod.error("获取类型失败 (Main/NPC/Chest)")
        return
    end

    F_dayTime    = patch.get_field(T_MAIN, "dayTime")
    F_netMode    = patch.get_field(T_MAIN, "netMode")
    F_spawnTileX = patch.get_field(T_MAIN, "spawnTileX")
    F_spawnTileY = patch.get_field(T_MAIN, "spawnTileY")
    F_npc        = patch.get_field(T_MAIN, "npc")
    F_npc_active = patch.get_field(T_NPC, "active")
    F_npc_type   = patch.get_field(T_NPC, "type")

    if not (F_dayTime and F_netMode and F_spawnTileX and F_spawnTileY
            and F_npc and F_npc_active and F_npc_type) then
        mod.error("获取字段失败")
        return
    end

    -- NPC.NewNPC：优先 4 参重载，其次 9 参重载
    M_new_npc = patch.get_method(T_NPC, "NewNPC", 4)
             or patch.get_method(T_NPC, "NewNPC", 9)
             or patch.get_method(T_NPC, "NewNPC")
    if not M_new_npc then
        mod.error("获取 NPC.NewNPC 失败")
        return
    end
    M_new_npc_argc = patch.method_param_count(M_new_npc) or 4

    -- Chest.SetupTravelShop（重构货架）
    M_setup_shop = patch.get_method(T_CHEST, "SetupTravelShop", 0)
                or patch.get_method(T_CHEST, "SetupTravelShop")
    if not M_setup_shop then
        mod.warn("未找到 Chest.SetupTravelShop，旅商货架可能为空")
    end

    -- 每帧回调方法：UpdateTime(0) -> Update(1) -> DoUpdate(1)
    M_tick = resolve_main("UpdateTime", {0})
          or patch.get_method(T_MAIN, "Update", 1)
          or patch.get_method(T_MAIN, "DoUpdate", 1)
    if not M_tick then
        mod.error("找不到每帧回调方法 (UpdateTime/Update/DoUpdate)")
        return
    end

    ready = true
    local ok, err = pcall(patch.install_hook, M_tick, { postfix = tick })
    if not ok then
        ready = false
        mod.error("安装 Hook 失败: " .. tostring(err))
        return
    end

    mod.info("该上班了旅商！！！ 已加载 (by KMLG666)  可怜的打工人！")
end

function cleanup()
    ready = false
    checked_today = false
    M_tick = nil
    mod.info("该上班了旅商！！！ 已卸载")
end

todo_list = { "setup" }
